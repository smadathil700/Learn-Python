from airflow import DAG
from airflow.providers.databricks.operators.databricks import DatabricksRunNowOperator
from datetime import datetime

with DAG(
    dag_id="pyspark_databricks_pipeline",
    start_date=datetime(2026,1,1),
    schedule_interval="@daily",
    catchup=False
) as dag:

    run_notebook = DatabricksRunNowOperator(
        task_id="run_pyspark_data_engineering_notebook",
        databricks_conn_id="databricks_default",
        job_id="41636805358367",  # Use the Job ID created in Databricks
        wait_for_termination=False,  # submit and move on
    )
